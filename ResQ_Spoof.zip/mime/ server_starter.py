import socket
port = 6006
sock = socket.socket()
sock.bind(('', port))
sock.listen(1000)
while True:
	conn, addr = sock.accept()
	data = conn.recv(10000).decode("utf-8")
	if data !=	"":
	 print(data)
