def clearf(file):
	fl = open(file, "w")
	fl.write("")
	fl.close()
def writef(file, data):
	fl = open(file, "w")
	fl.write(daga)
	fl.close()
def readf(f):
	fl = open(f)
	data = fl.read()
	fl.close()
	return data
print(readf("about.txt"))
def send_command(command):
	writef("command.txt", "insertjs")
	writef("to.txt", command)
while True:
	cmd = input("Command: ")
	if cmd == "clear_commands":
		clearf("command.txt")
		clearf("to.txt")
	elif cmd == "inserthtml":
		command = input("Enter html code: ")
		send_command(command)